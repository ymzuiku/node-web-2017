let React = require('react')

class Comp extends React.PureComponent {
  constructor(props) {
    super(props)
  }
  render() {
    return (
      <div>
        change password
      </div>
    )
  }
}
module.exports = Comp