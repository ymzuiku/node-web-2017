let colors = {
  black1: '#000',
  black2: '#284660',
  black3: '#9C9C9C',
  white1: '#fff',
  white2: '#F3F3F3',
  white2: '#F3F3F3',
  green1: '#68CC7B',
  green2: '#47BA5D',
  green3: '#59A65C',
  green4:'#6DFF5A',
  red1: '#F45864',
  red2: '#E4525D',
  blue1: '#3C84EB',
  blue2:'#C0D1F8',
}

module.exports = colors