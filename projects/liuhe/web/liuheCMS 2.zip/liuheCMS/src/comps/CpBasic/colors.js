let colors = {
  gradient1:'linear-gradient(180deg,#fff,#f9f9f9)',
  black1: '#000',
  black2: '#284660',
  black3: '#9C9C9C',
  white1: '#fff',
  white2: '#F5F5F5',
  white3: '#fafafa',
  green1: '#68CC7B',
  green2: '#47BA5D',
  green3: '#59A65C',
  green4:'#6DFF5A',
  red1: '#F45864',
  red2: '#E4525D',
  blue1: '#6152E1', // 251A6A //3C84EB
  blue2: '#3C84EB', // 251A6A //3C84EB
  blue3: '#C0D1F8',
  produck0:'#85DF88',
  produck1:'#55BE69',
  produck2:'#3FA452',
  produck3:'#3763CC',
  produck4:'#2B53B4',
}

module.exports = colors