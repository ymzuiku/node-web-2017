yarn run build
mv dist cms
cp -rf cms ../../public/page/
rm -rf cms